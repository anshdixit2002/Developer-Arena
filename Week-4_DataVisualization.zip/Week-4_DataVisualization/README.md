
## 🚀 Quick Start
1. **Clone/Download** repo
2. `pip install -r requirements.txt`
3. Open `analysis.ipynb` → **Run All** (Jupyter/VS Code)
4. View:
   - Charts: `visualizations/`
   - Insights: `report/insights.md`

## 📈 Key Findings
| Metric | Value |
|--------|-------|
| **Total Revenue** | ₹12,365,048 |
| **Top Product** | Laptop (₹663,636) |
| **Most Frequent** | Tablet (26 sales) |
| **Avg Price** | ₹25,809 |
| **Records** | 100 |

**Insights**:
- Laptops = highest revenue despite fewer sale
- No price-quantity correlation (r=0.008)
- South region strong for Laptops

## 📊 Sample Visuals
![Revenue by Product](visualizations/revenue_by_product.png)
![Quantity by Product](visualizations/product_quantity_bar.png)

## Workflow (7 Days)
- **D1-2**: Setup data
- **D3**: Explore (describe, head)
- **D4**: Analyze (groupby, sum, corr)
- **D5**: Charts (bar/line/pie)
- **D6**: Report insights
- **D7**: GitHub polish

## Tech Stack
- **Pandas**: Data loading/cleaning
- **Matplotlib**: Visualizations
- **Jupyter**: Interactive analysis

