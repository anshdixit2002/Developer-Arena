Day 6 Report: Sales Data Analysis Insights

This project analyzes a sales dataset with 100 records across products (Phone, Headphones, Laptop, Tablet, Monitor), regions (East, North, South, West), quantities (avg 4.78), prices (avg ₹25,809), and total sales (₹12,365,048 overall).
​

Key Metrics
Metric	Value
Total Records	100
​
Total Revenue	₹12,365,048
​
Avg Quantity	4.78
​
Avg Price	₹25,809
​
Max Total Sale	₹373,932
​
Top Insights
Laptop dominates revenue (₹663,636 total, highest avg price ₹27,652) – focus marketing here.
​

Tablet most frequent (26 sales), but lower revenue (₹628,608).
​

No price-quantity correlation (0.008) – sales volume not tied to price.
​

South leads regions for Laptops (9 sales); East balanced across products.
​

Visuals: Embed bar (quantity by product), pie (revenue share), line (trends) from analysis.ipynb in visualizations/.
​

Recommendation: Prioritize Laptops in South; analyze why Tablets sell more but earn less.